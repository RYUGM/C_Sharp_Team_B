﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_payment
{
    public class ParkingCar
    {

        public int ParkingSpot { get; set; }
        public string CarNumber { get; set; }
        public string DriverName { get; set; }
        public string PhoneNumber { get; set; }
        public DateTime ParkingTime { get; set; }
        public string result { get; set; }

        public string result1 { get; set; }



    }
}
